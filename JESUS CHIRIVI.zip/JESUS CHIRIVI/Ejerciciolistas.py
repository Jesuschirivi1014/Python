#EJERCICO DE LISTAS
Valor_a= 5
#               0 1 2 3 4 5
Valor_lista= [4, 7, 8, 9, 10, 20, 30, 40, 55]
print(Valor_lista[2])

#Ejercicio_listas_texto
lista_2= ["Saludo", "Juan", "Ricardo","incap"]
print(lista_2)

#Ejercicio_listas_aplicando_append
lista_2_append=("prueba")
print(lista_2_append)

#Ejercicio_listas_aplicando_pop
lista_2_pop=()
print(lista_2)
#Ejercicio_listas_aplicando_crear
lista_2_crear=()
print(lista_2)
